#include <iostream>
#include "ShortTest.h"
#include "ExtendedTest.h"

int main()
{
	testAll();
	testAllExtended();
	system("pause");
	return 0;
}