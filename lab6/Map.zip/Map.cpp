#include "Map.h"
#include <iostream>
#include "MapIterator.h"


Map::Map()
{
	this->m = 11;
	this->hashTable = new Node[this->m];
	this->len = 0;
	this->firstFree = 0;
	TElem empty;
	empty.first = EMPTY, empty.second = EMPTY;
	for (int i = 0; i < this->m; i++)
	{
		this->hashTable[i].info = empty;
	}
}

TValue Map::add(TKey c, TValue v)
{
	if (this->len == this->m)
		this->resize();
	if (c == 0)
		std::cout << "dragon";
	int pos = this->h(c);
	if (this->hashTable[pos].info.first == EMPTY || this->hashTable[pos].info.first == DELETED)
	{
		if (pos == this->firstFree)
			changeFirstFree();
		this->hashTable[pos].info.first = c;
		this->hashTable[pos].info.second = v;
		this->len++;
		return NULL_TVALUE;
	}
	else
	{
		int current = pos;
		if (this->hashTable[current].info.first == c)
		{
			TValue temp = this->hashTable[current].info.second;
			this->hashTable[current].info.second = v;
			return temp;
		}
		while (this->hashTable[current].next != -1)
		{
			if (this->hashTable[current].info.first == c)
			{
				TValue temp = this->hashTable[current].info.second;
				this->hashTable[current].info.second = v;
				return temp;
			}
			current = this->hashTable[current].next;
		}
		this->hashTable[this->firstFree].info.first = c;
		this->hashTable[this->firstFree].info.second = v;
		this->len++;
		this->hashTable[current].next = this->firstFree;
		this->changeFirstFree();
		return NULL_TVALUE;
	}
	
}

TValue Map::search(TKey c) const
{
	int pos = this->h(c);
	if (this->hashTable[pos].info.first == EMPTY || this->hashTable[pos].info.first == DELETED)
		return NULL_TVALUE;
	else
	{
		int current = pos;
		if (this->hashTable[current].info.first == c)
		{
			return this->hashTable[current].info.second;
		}
		while (this->hashTable[current].next != -1)
		{
			if (this->hashTable[current].info.first == c)
			{
				return this->hashTable[current].info.second;
			}
			current = this->hashTable[current].next;
		}
		return NULL_TVALUE;
	}
	
}

TValue Map::remove(TKey c)
{
	int pos = this->h(c);
	if (this->hashTable[pos].info.first == EMPTY || this->hashTable[pos].info.first == DELETED)
		return NULL_TVALUE;
	else
	{
		int current = pos;
		if (this->hashTable[current].info.first == c)
		{
			TValue temp = this->hashTable[current].info.second;
			this->hashTable[current].info.first = DELETED;
			this->hashTable[current].info.second = DELETED;
			this->len--;
			changeFirstFree();
			return temp;
		}
		while (this->hashTable[current].next != -1)
		{
			if (this->hashTable[current].info.first == c)
			{
				TValue temp = this->hashTable[current].info.second;
				this->hashTable[current].info.first = DELETED;
				this->hashTable[current].info.second = DELETED;
				this->len--;
				changeFirstFree();
				return temp;
			}
			current = this->hashTable[current].next;
		}
		return NULL_TVALUE;
	}
}


int Map::size() const
{
	return this->len;
}

bool Map::isEmpty() const
{
	return this->len == 0;
}

MapIterator Map::iterator() const
{
	return MapIterator(*this);
}

Map::~Map()
{
	delete this->hashTable;
}

void Map::resize()
{	
	Node* temp = new Node[2 * this->m];
	int first = 0;
	this->m *= 2;
	for (int i = 0; i < this->m; i++)
	{
		temp[i].info.first = EMPTY;
		temp[i].info.second = EMPTY;
	}
	for (int i = 0; i < this->m/2; i++)
	{
		if (this->hashTable[i].info.first == 0)
			std::cout << "dragon";
		int pos = this->h(this->hashTable[i].info.first);
		if (temp[pos].info.first == EMPTY || temp[pos].info.first == DELETED)
			temp[pos].info = this->hashTable[i].info;
		else
		{
			int current = pos;
			while (temp[current].next != -1)
				current = temp[current].next;
			temp[first].info = this->hashTable[i].info;
			temp[current].next = first;
			for (int j = 0; j < this->m; j++)
				if (temp[j].info.first == EMPTY)
				{
					first = j;
					break;
				}
		}

	}
	delete[] this->hashTable;
	this->hashTable = temp;
	this->firstFree = -1;
	this->changeFirstFree();
}

void Map::changeFirstFree()
{
	this->firstFree++;
	while (this->firstFree < this->m && this->hashTable[this->firstFree].info.first != EMPTY && this->hashTable[this->firstFree].info.first != DELETED)
		this->firstFree++;
}
