#include "MapIterator.h"



MapIterator::MapIterator(const Map& mp): mp{mp}
{
	this->current = 0;
	while (this->mp.hashTable[current].info.first == EMPTY || this->mp.hashTable[current].info.first == DELETED)
		this->current++;
}

void MapIterator::first()
{
	this->current = 0;
	while (this->mp.hashTable[current].info.first == EMPTY || this->mp.hashTable[current].info.first == DELETED)
		this->current++;
}

void MapIterator::next()
{
	if (valid())
	{
		this->current++;
		while (this->mp.hashTable[current].info.first == EMPTY || this->mp.hashTable[current].info.first == DELETED)
			current++;
	}
	else
		throw std::exception();
}

bool MapIterator::valid() const
{
	return this->current < this->mp.m;
}


TElem MapIterator::getCurrent() const
{
	if (valid())
		return mp.hashTable[this->current].info;
	else
		throw std::exception();
}

MapIterator::~MapIterator()
{
}
